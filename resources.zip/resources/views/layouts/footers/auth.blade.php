
<footer class="footer d-none d-sm-block">
                    <p>© Super Admin Responsive. All rights reserved.</p>

                    <ul class="footer__nav">
                        <a href="#">Homepage</a>
                        <a href="#">Company</a>
                        <a href="#">Support</a>
                        <a href="#">News</a>
                        <a href="#">Contacts</a>
                    </ul>
                </footer>
               